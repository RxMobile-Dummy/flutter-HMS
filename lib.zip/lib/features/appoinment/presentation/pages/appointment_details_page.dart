import 'package:flutter/material.dart';
import 'package:hospital_management/features/appoinment/data/model/get_appointment_model.dart';
import 'package:hospital_management/utils/colors.dart';
import 'package:intl/intl.dart';

import '../../../../core/strings/strings.dart';

class AppointmentDetailsPage extends StatefulWidget {
  GetAppointmentModel getAppointmentModel;
  int index;
   AppointmentDetailsPage({Key? key,required this.getAppointmentModel, required this.index}) : super(key: key);

  @override
  _AppointmentDetailsPageState createState() => _AppointmentDetailsPageState();
}

class _AppointmentDetailsPageState extends State<AppointmentDetailsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          "Appointment Details",
          style: TextStyle(
              fontWeight: FontWeight.w500,
              fontStyle: FontStyle.normal,
              //fontFamily: 'Open Sans',
              fontSize: 22,
              color: Colors.black),
        ),
        leading: InkWell(
            child: const Icon(
              Icons.arrow_back_ios,
              size: 20,
              color: Colors.black,
            ),
            onTap: () {
              Navigator.of(context).pop();
            }),
      ),
      body: buildWidget(),
    );
  }

  buildWidget() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        // mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Container(
                    height: 140,
                    width: MediaQuery.of(context).size.width / 2.6,
                    decoration: BoxDecoration(
                        color: Colors.blue.shade100,
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  Container(
                    height: 190,
                    width: MediaQuery.of(context).size.width / 2.6,
                    decoration:  BoxDecoration(
                      image: DecorationImage(
                        image: userProfilePic(
                          imagePath:
                          (widget.getAppointmentModel.data![widget.index].patientProfilePic != null && widget.getAppointmentModel.data![widget.index].patientProfilePic != "")
                              ? "${Strings.baseUrl}${widget.getAppointmentModel.data![widget.index].patientProfilePic}"
                              : "",),
                        //AssetImage("assets/images/ii_1.png"),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsets.only(left: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${widget.getAppointmentModel.data![widget.index].firstName}",
                      maxLines: 3,
                      style: TextStyle(
                          fontSize: 22,
                          color: (Theme.of(context).brightness ==
                              Brightness.dark)
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.w500),
                    ),
                    Text(
                      "${widget.getAppointmentModel.data![widget.index].lastName}",
                      maxLines: 3,
                      style: TextStyle(
                          fontSize: 22,
                          color: (Theme.of(context).brightness ==
                              Brightness.dark)
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              )
            ],
          ),
          const SizedBox(height: 25,),
          Text(
            "Appointment On",
            style: TextStyle(
                fontSize: 16,
                color: (Theme.of(context).brightness ==
                    Brightness.dark)
                    ? Colors.white
                    : Colors.grey.shade400,
                fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 10,),
          IntrinsicHeight(
            child: Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  getFormattedDateFromFormattedString(
                      currentFormat: "dd-MM-yyyy - HH:mm",
                      desiredFormat: "dd MMM yyyy",
                      value:  "${widget.getAppointmentModel.data![widget.index].appointmentDate} - 00:00".replaceAll("/", "-")),
                  // DateFormat.yMMMMd().format(DateTime.parse(DateFormat('dd-MM-yyyy hh:mm:ss a').parse("30/08/2022".replaceAll("/", "-")).toString())),
                  style: const TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.w500),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 2),
                  child: VerticalDivider(
                    color: Colors.grey.shade400,
                    thickness: 2,
                  ),
                ),
                Text(
                  widget.getAppointmentModel.data![widget.index].timeSlot ?? "",
                  style: const TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.w500),
                ),
              ],
            ),),
          const SizedBox(height: 25,),
          Text(
            "Appointment For",
            style: TextStyle(
                fontSize: 16,
                color: (Theme.of(context).brightness ==
                    Brightness.dark)
                    ? Colors.white
                    : Colors.grey.shade400,
                fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 10,),
          Text(
            widget.getAppointmentModel.data![widget.index].disease ?? "",
            style: const TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 25,),
          Text(
            "Attachment",
            style: TextStyle(
                fontSize: 16,
                color: (Theme.of(context).brightness ==
                    Brightness.dark)
                    ? Colors.white
                    : Colors.grey.shade400,
                fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
               Text(
                widget.getAppointmentModel.data![widget.index].fileData ?? "",
                style: TextStyle(
                    fontSize: 16,
                    color: Colors.black,
                    fontWeight: FontWeight.w500),
              ),
              Row(
                children: const [
                  Icon(
                      Icons.remove_red_eye,
                    color: CustomColors.colorDarkBlue,
                    size: 16,
                  ),
                  SizedBox(width: 7,),
                  Text(
                    "View",
                    style: TextStyle(
                        fontSize: 16,
                        color: CustomColors.colorDarkBlue,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              )
            ],
          )
        ],
      ),
    );
  }
  userProfilePic({String? imagePath}) {
    return NetworkImage(
        (imagePath == null || imagePath == "")
            ? "https://mpng.subpng.com/20190123/jtv/kisspng-computer-icons-vector-graphics-person-portable-net-myada-baaranmy-teknik-servis-hizmetleri-5c48d5c2849149.051236271548277186543.jpg"
            : imagePath);
  }

  String getFormattedDateFromFormattedString(
      {required String currentFormat,
        required String desiredFormat,
        String? value}) {
    String formattedDate = "";
    if (value != null || value!.isNotEmpty) {
      try {
        DateTime dateTime = DateFormat(currentFormat).parse(value, true).toLocal();
        formattedDate = DateFormat(desiredFormat).format(dateTime);
      } catch (e) {
        print("$e");
      }
    }
    // print("Formatted date time:  $formattedDate");
    return formattedDate.toString();
  }

}
