class SendDoctorFeedbackModel {
  bool? success;
  List? data;
  String? message;
  String? error;

  SendDoctorFeedbackModel({this.success, this.data, this.message, this.error});

  SendDoctorFeedbackModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
      data = [];
    message = json['message'];
    error = json['error'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['message'] = this.message;
    data['error'] = this.error;
    return data;
  }
}