import '../../../../core/base/base_bloc.dart';
import '../../data/model/send_patient_feedback.dart';

class SendDoctorFeedbackState extends BaseState {
  SendDoctorFeedbackModel? model;

  SendDoctorFeedbackState({this.model});
}
