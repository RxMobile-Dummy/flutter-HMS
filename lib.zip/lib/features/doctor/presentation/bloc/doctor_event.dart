import 'package:hospital_management/features/doctor/data/model/get_doctor_model.dart';

import '../../../../core/base/base_bloc.dart';

class GetDoctorEvent extends BaseEvent {

  GetDoctorEvent();
}

class GetDoctorSuccessEvent extends BaseEvent {
  GetDoctorModel? model;

  GetDoctorSuccessEvent({this.model});
}