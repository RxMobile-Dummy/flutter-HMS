import 'package:hospital_management/features/doctor/data/model/get_doctor_model.dart';

import '../../../../core/base/base_bloc.dart';

class GetDoctorState extends BaseState {
  GetDoctorModel? model;

  GetDoctorState({this.model});
}