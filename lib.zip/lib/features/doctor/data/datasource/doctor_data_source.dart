import 'package:hospital_management/features/doctor/data/model/get_doctor_model.dart';

import '../../domain/usecases/get_doctor_usecase.dart';

abstract class DoctorDataSource {
  Future<GetDoctorModel> getDoctorCall(GetDoctorParams params);
}