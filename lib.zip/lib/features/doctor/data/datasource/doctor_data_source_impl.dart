import 'package:hospital_management/features/doctor/data/datasource/doctor_data_source.dart';
import 'package:hospital_management/features/doctor/data/model/get_doctor_model.dart';
import 'package:hospital_management/features/doctor/domain/usecases/get_doctor_usecase.dart';

import '../../../../core/api_call/baseClient.dart';

class DoctorDataSourceImpl implements DoctorDataSource {
  final ApiClient _apiClient;

  DoctorDataSourceImpl(this._apiClient);

  @override
  Future<GetDoctorModel> getDoctorCall(GetDoctorParams params) async {
    final response = await _apiClient.getDoctor();
    print(response);
    var data;
    if (response != null) {
      data = response;
      return data;
    } else {
      print('failed');
    }
    return data;
  }




}