class GetDoctorModel {
  bool? success;
  List<Data>? data;
  String? message;
  String? error;

  GetDoctorModel({this.success, this.data, this.message, this.error});

  GetDoctorModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
    message = json['message'];
    error = json['error'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['message'] = this.message;
    data['error'] = this.error;
    return data;
  }
}

class Data {
  int? id;
  String? yearsOfExperience;
  String? specialistField;
  String? about;
  String? createAt;
  String? nextAvailableAt;
  String? education;
  String? inClinicAppointmentFees;
  String? rating;
  String? contactNumber;
  String? email;
  String? dateOfBirth;
  String? lastName;
  String? profilePic;
  String? firstName;
  String? gender;
  String? bloodGroup;

  Data(
      {this.id,
        this.yearsOfExperience,
        this.specialistField,
        this.about,
        this.createAt,
        this.nextAvailableAt,
        this.education,
        this.inClinicAppointmentFees,
        this.rating,
        this.contactNumber,
        this.email,
        this.dateOfBirth,
        this.lastName,
        this.profilePic,
        this.firstName,
        this.gender,
        this.bloodGroup});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    yearsOfExperience = json['years_of_experience'];
    specialistField = json['specialist_field'];
    about = json['about'];
    createAt = json['create_at'];
    nextAvailableAt = json['next_available_at'];
    education = json['education'];
    inClinicAppointmentFees = json['in_clinic_appointment_fees'];
    rating = json['rating'];
    contactNumber = json['contact_number'];
    email = json['email'];
    dateOfBirth = json['date_of_birth'];
    lastName = json['last_name'];
    profilePic = json['profile_pic'];
    firstName = json['first_name'];
    gender = json['gender'];
    bloodGroup = json['blood_group'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['years_of_experience'] = this.yearsOfExperience;
    data['specialist_field'] = this.specialistField;
    data['about'] = this.about;
    data['create_at'] = this.createAt;
    data['next_available_at'] = this.nextAvailableAt;
    data['education'] = this.education;
    data['in_clinic_appointment_fees'] = this.inClinicAppointmentFees;
    data['rating'] = this.rating;
    data['contact_number'] = this.contactNumber;
    data['email'] = this.email;
    data['date_of_birth'] = this.dateOfBirth;
    data['last_name'] = this.lastName;
    data['profile_pic'] = this.profilePic;
    data['first_name'] = this.firstName;
    data['gender'] = this.gender;
    data['blood_group'] = this.bloodGroup;
    return data;
  }
}