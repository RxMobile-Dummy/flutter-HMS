class Strings{
  static const kNoInternetConnection = "No Internet Connection";
  static const kServerFailureMessage = 'Server Failure';
  static const kCacheFailureMessage = 'Cache Failure';
  static const kInternalServerError = "Internal Server Error";
  static const kNoRecordsFound = "No Records Found";
  static const baseUrl = "https://0826-180-211-112-179.in.ngrok.io/";
}