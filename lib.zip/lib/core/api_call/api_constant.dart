class ApiHeaders{

}

class ApiEndpoints{

}

class ApiRequestParams{

}