import 'package:flutter/material.dart';

class CustomColors {
  static const Color colorRed = Color(0xfff96060);
  //static const Color colorBlue = Color(0xff6074f9);
  static const Color colorPurple = Color(0xff8561f9);
  static const Color colorDarkBlue = Color(0xff055099);
  static const Color colorBrightBlue = Color(0xff0096FF);
  static const Color colorPowerBlue = Color(0xffB6D0E2);
}